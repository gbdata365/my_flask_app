# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

# 데이터 분석 대시보드 시스템

## 프로젝트 개요
Flask 기반의 데이터 분석 대시보드 시스템으로, 여러 카테고리의 통계 데이터를 시각화하고 분석하는 웹 애플리케이션입니다.

## 핵심 아키텍처

### 애플리케이션 구조
- **main_app.py**: Flask 애플리케이션 팩토리 패턴 사용
- **동적 블루프린트 시스템**: 숫자로 시작하는 폴더명을 자동으로 카테고리로 인식하여 라우트 생성
- **카테고리별 독립 구조**: 각 카테고리(1_giup, 2_의료통계 등)는 독립적인 routes, data, templates를 가짐

## 프로젝트 개요
- **목적**: 포미서비스 AI SNS 마케팅 서비스 홍보 및 상담 신청을 위한 단일 페이지 웹사이트
- **배포**: GitHub Pages 또는 정적 호스팅
- **구조**: 단순한 단일 폴더 구조

## 기술 스택
- HTML5
- CSS3
- 파이썬 언어어
- Tailwind.css 사용


## 개발 규칙
- 프레임워크나 빌드 도구 사용 금지
- 모든 코드는 각각의 파일에 포함 (HTML, CSS, py 분리)
- ES6+ 문법 사용 가능
- 반응형 디자인 필수 (Mobile-first approach)
- 부드러운 스크롤 애니메이션 구현
- 인터섹션 옵저버를 활용한 스크롤 애니메이션
- 폼 유효성 검사 구현

## 디자인 가이드라인
- **색상 팔레트** (UMAUMA Icons 테마):
  ```css
  --primary-dark: #1243A6;    /* 진한 파랑 - 주요 버튼, 헤더 */
  --primary: #1D64F2;         /* 밝은 파랑 - 링크, 하이라이트 */
  --dark: #011C40;            /* 네이비 - 텍스트, 배경 */
  --light: #F2EED8;           /* 크림 - 배경, 카드 */
  --accent: #F24822;          /* 오렌지레드 - CTA, 강조 */
  ```
- **색상 사용 가이드**:
  - 메인 배경: --light (#F2EED8)
  - 텍스트: --dark (#011C40)
  - 주요 버튼: --primary-dark (#1243A6)
  - 호버 효과: --primary (#1D64F2)
  - CTA 버튼: --accent (#F24822)
  - 섹션 구분: --dark (#011C40) 배경에 흰색 텍스트
- **폰트**: 
  - 제목: Pretendard 또는 Noto Sans KR Bold
  - 본문: Pretendard 또는 Noto Sans KR Regular
- **애니메이션**: 
  - Fade-in, Slide-up 효과
  - 호버 효과 및 마이크로 인터랙션

## 개발 명령어
- **로컬 서버 실행**: 
  - Python: `python -m http.server 8000` 또는 `python3 -m http.server 8000`
- **파일 구조**:
 
  - `style.css` - 모든 스타일시트
  - `script.js` - JavaScript 로직

- **CSS 구성**: 
  - CSS 변수로 색상 팔레트 정의
  - 모바일 우선 미디어 쿼리
  - Tailwind.css CDN 사용
- **JavaScript 패턴**:
  - DOMContentLoaded 이벤트 리스너 사용
  - Intersection Observer로 스크롤 애니메이션
  - 이벤트 위임 패턴 활용
  - 폼 제출 처리 및 유효성 검사

### 디렉토리 구조 패턴
```
프로젝트루트/
├── main_app.py                 # 메인 애플리케이션
├── module/
│   └── db_config.py           # 데이터베이스 연결 설정
├── templates/                 # 공통 템플릿
│   └── base.html             # 기본 레이아웃
└── {숫자}_{카테고리명}/        # 동적 카테고리 폴더
    ├── routes/               # 카테고리별 라우트 파일
    ├── data/                # 엑셀 데이터 파일
    ├── static/              # 카테고리별 정적 파일
    ├── html_docs/           # HTML 문서
    └── markdown_docs/       # 마크다운 문서
```

### 데이터베이스 연결
- **PyMySQL** 사용
- **환경변수 기반 설정**: DB_HOST, DB_USER, DB_PASS, DB_NAME
- **기본값**: localhost, happyUser, happy7471!, gbd_data

## 개발 명령어

### 서버 실행
```bash
python main_app.py
# 또는
python -m flask run
```

### 개발 환경 설정
- Flask 디버그 모드는 main_app.py에서 기본 활성화
- 포트: 5000 (Flask 기본)

## 핵심 컴포넌트

### DashboardGenerator 클래스 (1_giup/routes/dashboard__module.py)
재사용 가능한 대시보드 생성을 위한 핵심 클래스:

**주요 기능**:
- 1_giup/data 폴더에 원시자료(giup_source.csv), 최종자료(집계표_년월) 여기서 년월은 원시자료의 년도와 월이 들어가도록 , 최종자료를 생성하는 .py 을 routes 폴더에 작성
- data  폴더에 pdf 내용을 보고 정리하여 md화일로 만들어서 markdown_docs 폴더에 저장
- html_docs, markdown_docs, routes 폴더에 있는 화일명만 세부메뉴로 만들어서 실행할수 있도록
- routes 폴더에 dashbord.py 화일을 만들어 집계표.xlsx 에 있는 내용을 정리하여 표와 그래프로 나타낼수 있도록...
(시도선택 가능하게, 년도와 월이 추가될 예정이므로 시계열로  표시되게)
- Excel 데이터 자동 로드 및 전처리
- 특수문자 처리 (기본값: '*' → 1)
- 년도/월 데이터 자동 분리
- 그룹별 데이터 집계 (시도/시군구 구조)
- Plotly 기반 인터랙티브 차트 생성


**사용 패턴**:
```python
generator = DashboardGenerator(
    data_path=Path("data/파일명.xlsx"),
    numeric_columns=['컬럼1', '컬럼2', '컬럼3'],
    group_col='시도',
    subgroup_col='시군구',
    time_col='년도',
    highlight_region='경상북도'  # 선택적 강조 지역
)

generator.load_and_process_data()
html_content = generator.generate_html(
    title="대시보드 제목",
    chart_columns=['컬럼1', '컬럼2'],  # 차트에 표시할 컬럼 선택
    column_display_names={'컬럼1': '표시명1', '컬럼2': '표시명2'}
)
```

### 라우트 파일 패턴
각 카테고리의 routes/ 폴더에 있는 Python 파일들은:
- Flask Blueprint 또는 단순 함수로 구현
- DashboardGenerator를 활용한 표준화된 대시보드 생성
- Excel 파일 기반 데이터 처리

## 데이터 처리 규칙

### Excel 파일 구조 가정
- **필수 컬럼**: 년도, 시도, 시군구
- **숫자 컬럼**: 쉼표 포함 가능, 특수문자('*') 처리
- **년도 형식**: YYYYMM 또는 YYYY

### 데이터 전처리 자동화
- 특수문자 자동 변환 (기본: '*' → 1)
- 쉼표 제거 및 숫자 변환
- 결측값 0으로 대체
- 년/월 자동 분리

## 템플릿 시스템

### 기본 레이아웃 (templates/base.html)
- Bootstrap 5 사용
- 조건부 사이드바 (메인 페이지에서만 표시)
- 반응형 그리드 시스템

### 동적 메뉴 생성
- `get_category_folders()` 함수로 숫자 시작 폴더 자동 감지
- 카테고리별 자동 링크 생성

## 주요 의존성
- **Flask**: 웹 프레임워크
- **pan2das**: 데이터 처리
- **plotly**: 인터랙티브 차트
- **pymysql**: MySQL 연결
- **openpyxl**: Excel 파일 읽기
- **Bootstrap 5**: 프론트엔드 프레임워크 (CDN)

## 개발 가이드라인

### 새 카테고리 추가
1. `{숫자}_{카테고리명}` 폴더 생성
2. `routes/` 폴더에 라우트 파일 추가
3. `data/` 폴더에 Excel 파일 배치
4. DashboardGenerator를 활용한 표준 대시보드 구현

### 데이터 파일 위치
- Excel 파일은 각 카테고리의 `data/` 폴더에 배치
- 파일명과 경로는 routes 파일에서 하드코딩됨

### 차트 커스터마이징
- Plotly 차트는 DashboardGenerator 클래스에서 생성
- 강조 지역 설정으로 특정 지역 하이라이트 가능
- 상위 N개 지역만 표시 (기본값: 10개)

## 보안 고려사항
- 데이터베이스 자격증명이 기본값으로 하드코딩되어 있음
- 환경변수 사용 권장: DB_HOST, DB_USER, DB_PASS, DB_NAME