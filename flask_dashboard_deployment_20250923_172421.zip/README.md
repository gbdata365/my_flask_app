# Flask Dashboard 배포 패키지

생성일: 2025-09-23 17:24:29.47
생성자: user

## 📦 패키지 내용

이 패키지에는 Flask Dashboard를 Docker로 배포하는데 필요한 모든 파일이 포함되어 있습니다.

### 핵심 구성요소
- Docker 설정: docker-compose.yml, Dockerfile
- Flask 애플리케이션: main_app.py, module/, templates/
- 웹 서버 설정: nginx/ 디렉토리
- 데이터베이스 설정: database/ 디렉토리
- 배포 스크립트: deploy.bat

## 🚀 빠른 설치 가이드

### 1. 요구사항
- Docker Desktop for Windows
- Windows 10/11

### 2. 설치 과정
1. install.bat 더블클릭 또는
2. PowerShell에서 .\install.bat 실행
3. 웹 브라우저에서 http://localhost 접속

## ⚠️ 보안 주의사항
1. .env 파일의 기본 비밀번호를 반드시 변경하세요
2. 방화벽에서 필요한 포트만 개방하세요

## 📖 상세 가이드
Docker_배포_가이드.md 파일을 참고하세요.

---
배포 패키지 버전: 20250923_172421
